"""
This playbook enriches a single IOC using Google Threat Intelligence and determines whether it is malicious based on verdict and threat score.\nBased on the enrichment result, it optionally blocks the IOC and records structured intelligence as an artifact note for SOC review.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'get_ioc_report' block
    get_ioc_report(container=container)

    return

@phantom.playbook_block()
def get_ioc_report(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("get_ioc_report() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Retrieves threat intelligence details for the provided IOC from Google Threat 
    # Intelligence.
    ################################################################################

    playbook_input_ioc = phantom.collect2(container=container, datapath=["playbook_input:ioc"])

    parameters = []

    # build parameters list for 'get_ioc_report' call
    for playbook_input_ioc_item in playbook_input_ioc:
        if playbook_input_ioc_item[0] is not None:
            parameters.append({
                "entity": playbook_input_ioc_item[0],
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("get ioc report", parameters=parameters, name="get_ioc_report", assets=["test_gti"], callback=parse_gti_enrichment_output)

    return


@phantom.playbook_block()
def parse_gti_enrichment_output(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("parse_gti_enrichment_output() called")

    ################################################################################
    # Extracts relevant fields from the GTI response for decision-making and reporting.
    ################################################################################

    get_ioc_report_result_data = phantom.collect2(container=container, datapath=["get_ioc_report:action_result.data.*.data"], action_results=results)

    get_ioc_report_result_item_0 = [item[0] for item in get_ioc_report_result_data]

    parse_gti_enrichment_output__ioc_value = None
    parse_gti_enrichment_output__threat_score = None
    parse_gti_enrichment_output__verdict = None
    parse_gti_enrichment_output__confidence = None
    parse_gti_enrichment_output__severity = None
    parse_gti_enrichment_output__categories = None
    parse_gti_enrichment_output__malware_families = None
    parse_gti_enrichment_output__first_seen = None
    parse_gti_enrichment_output__last_seen = None
    parse_gti_enrichment_output__raw_attributes = None
    parse_gti_enrichment_output__artifact_data = None
    parse_gti_enrichment_output__ioc_type = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    """
    Parse GTI IOC Report output into SOAR variables.
    Direct assignment to output variables:
        parse_gti_enrichment_output__<field>
    """
    def normalize_soar_severity(value):
        """Map GTI severity with Splunk SOAR severity"""
        if not value:
            return ""
    
        value = str(value).strip().upper()
    
        mapping = {
            "SEVERITY_HIGH": "high",
            "SEVERITY_MEDIUM": "medium",
            "SEVERITY_LOW": "low",
        }
    
        return mapping.get(value, "")
    
    def get_path(dct, path, default=None):
        cur = dct
        for key in path:
            if not isinstance(cur, dict):
                return default
            cur = cur.get(key)
            if cur is None:
                return default
        return cur

    ioc_type = get_ioc_report_result_item_0[0]["type"]
    item = get_ioc_report_result_item_0[0]["attributes"]

    parse_gti_enrichment_output__ioc_value = get_ioc_report_result_item_0[0]["id"]
    parse_gti_enrichment_output__threat_score = get_path(
        item, ["gti_assessment", "threat_score", "value"], 0
    )
    parse_gti_enrichment_output__verdict = get_path(
        item, ["gti_assessment", "verdict", "value"], "VERDICT_UNKNOWN"
    )
    parse_gti_enrichment_output__confidence = get_path(
        item, ["gti_assessment", "contributing_factors", "gti_confidence_score"], 0
    )
    parse_gti_enrichment_output__severity = normalize_soar_severity(get_path(
        item, ["gti_assessment", "severity", "value"], ""
    ))
    parse_gti_enrichment_output__categories = get_path(
        item, ["gti_assessment", "contributing_factors", "normalised_categories"], []
    )
    parse_gti_enrichment_output__malware_families = get_path(
        item,
        ["gti_assessment", "contributing_factors", "mandiant_association_malware"],
        False,
    )
    parse_gti_enrichment_output__first_seen = item.get("first_seen_itw_date")
    parse_gti_enrichment_output__last_seen = item.get("last_seen_itw_date")

    # STRICT pass-through: identical to file content
    parse_gti_enrichment_output__raw_attributes = item.get("gti_assessment", {})
    parse_gti_enrichment_output__artifact_data = {
        "cef": {
            f"gti_{ioc_type}__ioc_value": parse_gti_enrichment_output__ioc_value,
            f"gti_{ioc_type}__threat_score": parse_gti_enrichment_output__threat_score,
            f"gti_{ioc_type}__verdict": parse_gti_enrichment_output__verdict,
            f"gti_{ioc_type}__confidence": parse_gti_enrichment_output__confidence,
            f"gti_{ioc_type}__severity": parse_gti_enrichment_output__severity,
        }
    }
    parse_gti_enrichment_output__ioc_type = ioc_type
    

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="parse_gti_enrichment_output__inputs:0:get_ioc_report:action_result.data.*.data", value=json.dumps(get_ioc_report_result_item_0))

    phantom.save_block_result(key="parse_gti_enrichment_output:ioc_value", value=json.dumps(parse_gti_enrichment_output__ioc_value))
    phantom.save_block_result(key="parse_gti_enrichment_output:threat_score", value=json.dumps(parse_gti_enrichment_output__threat_score))
    phantom.save_block_result(key="parse_gti_enrichment_output:verdict", value=json.dumps(parse_gti_enrichment_output__verdict))
    phantom.save_block_result(key="parse_gti_enrichment_output:confidence", value=json.dumps(parse_gti_enrichment_output__confidence))
    phantom.save_block_result(key="parse_gti_enrichment_output:severity", value=json.dumps(parse_gti_enrichment_output__severity))
    phantom.save_block_result(key="parse_gti_enrichment_output:categories", value=json.dumps(parse_gti_enrichment_output__categories))
    phantom.save_block_result(key="parse_gti_enrichment_output:malware_families", value=json.dumps(parse_gti_enrichment_output__malware_families))
    phantom.save_block_result(key="parse_gti_enrichment_output:first_seen", value=json.dumps(parse_gti_enrichment_output__first_seen))
    phantom.save_block_result(key="parse_gti_enrichment_output:last_seen", value=json.dumps(parse_gti_enrichment_output__last_seen))
    phantom.save_block_result(key="parse_gti_enrichment_output:raw_attributes", value=json.dumps(parse_gti_enrichment_output__raw_attributes))
    phantom.save_block_result(key="parse_gti_enrichment_output:artifact_data", value=json.dumps(parse_gti_enrichment_output__artifact_data))
    phantom.save_block_result(key="parse_gti_enrichment_output:ioc_type", value=json.dumps(parse_gti_enrichment_output__ioc_type))

    update_artifact(container=container)

    return


@phantom.playbook_block()
def update_artifact(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("update_artifact() called")

    ################################################################################
    # Updates the artifact fields such as severity and enrichment context.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.id","artifact:*.id"])
    parse_gti_enrichment_output__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:severity")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__artifact_data = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:artifact_data")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    # build parameters list for 'update_artifact' call
    for container_artifact_item in container_artifact_data:
        parameters.append({
            "name": None,
            "tags": None,
            "label": None,
            "severity": parse_gti_enrichment_output__severity,
            "cef_field": None,
            "cef_value": None,
            "input_json": parse_gti_enrichment_output__artifact_data,
            "artifact_id": container_artifact_item[0],
            "cef_data_type": None,
            "overwrite_tags": None,
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.custom_function(custom_function="community/artifact_update", parameters=parameters, name="update_artifact", callback=check_malicious_ioc)

    return


@phantom.playbook_block()
def check_malicious_ioc(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_malicious_ioc() called")

    ################################################################################
    # Evaluates whether the IOC is malicious based on verdict and threat score.
    ################################################################################

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        logical_operator="or",
        conditions=[
            ["parse_gti_enrichment_output:custom_function:threat_score", ">=", 90],
            ["parse_gti_enrichment_output:custom_function:severity", "==", "high"],
            ["parse_gti_enrichment_output:custom_function:verdict", "==", "VERDICT_MALICIOUS"]
        ],
        conditions_dps=[
            ["parse_gti_enrichment_output:custom_function:threat_score", ">=", 90],
            ["parse_gti_enrichment_output:custom_function:severity", "==", "high"],
            ["parse_gti_enrichment_output:custom_function:verdict", "==", "VERDICT_MALICIOUS"]
        ],
        name="check_malicious_ioc:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        check_ioc_type(action=action, success=success, container=container, results=results, handle=handle)
        return

    # check for 'else' condition 2
    create_ioc_note(action=action, success=success, container=container, results=results, handle=handle)

    return


@phantom.playbook_block()
def block_ip(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("block_ip() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Blocks the malicious IP using the configured enforcement control.
    ################################################################################

    playbook_input_ioc = phantom.collect2(container=container, datapath=["playbook_input:ioc"])

    parameters = []

    # build parameters list for 'block_ip' call
    for playbook_input_ioc_item in playbook_input_ioc:
        if playbook_input_ioc_item[0] is not None:
            parameters.append({
                "ip": playbook_input_ioc_item[0],
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("block ip", parameters=parameters, name="block_ip", assets=["test-zscaler"], callback=create_malicious_ip_note)

    return


@phantom.playbook_block()
def create_malicious_ip_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_malicious_ip_note() called")

    ################################################################################
    # Prepares a detailed artifact note summarizing malicious IP intelligence.
    ################################################################################

    block_ip_result_data = phantom.collect2(container=container, datapath=["block_ip:action_result.status"], action_results=results)
    parse_gti_enrichment_output__ioc_value = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_value")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__threat_score = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:threat_score")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__verdict = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:verdict")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:severity")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__ioc_type = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_type")) != "" else "null")  # pylint: disable=used-before-assignment

    block_ip_result_item_0 = [item[0] for item in block_ip_result_data]

    create_malicious_ip_note__artifact_note = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    block_note = f"As the IP is malicious, It is blocked."
    
    create_malicious_ip_note__artifact_note = (
        f"IP : {parse_gti_enrichment_output__ioc_value}\n"
        f"Threat_score : {parse_gti_enrichment_output__threat_score}\n"
        f"Verdict : {parse_gti_enrichment_output__verdict}\n"
        f"{block_note}"
    )    
    phantom.debug(f"artifact note : {create_malicious_ip_note__artifact_note}")

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="create_malicious_ip_note__inputs:0:parse_gti_enrichment_output:custom_function:ioc_value", value=json.dumps(parse_gti_enrichment_output__ioc_value))
    phantom.save_block_result(key="create_malicious_ip_note__inputs:1:parse_gti_enrichment_output:custom_function:threat_score", value=json.dumps(parse_gti_enrichment_output__threat_score))
    phantom.save_block_result(key="create_malicious_ip_note__inputs:2:parse_gti_enrichment_output:custom_function:verdict", value=json.dumps(parse_gti_enrichment_output__verdict))
    phantom.save_block_result(key="create_malicious_ip_note__inputs:3:parse_gti_enrichment_output:custom_function:severity", value=json.dumps(parse_gti_enrichment_output__severity))
    phantom.save_block_result(key="create_malicious_ip_note__inputs:4:block_ip:action_result.status", value=json.dumps(block_ip_result_item_0))
    phantom.save_block_result(key="create_malicious_ip_note__inputs:5:parse_gti_enrichment_output:custom_function:ioc_type", value=json.dumps(parse_gti_enrichment_output__ioc_type))

    phantom.save_block_result(key="create_malicious_ip_note:artifact_note", value=json.dumps(create_malicious_ip_note__artifact_note))

    add_malicious_ip_artifact_note(container=container)

    return


@phantom.playbook_block()
def create_ioc_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_ioc_note() called")

    ################################################################################
    # Prepares an informational artifact note for a non-malicious IOC.
    ################################################################################

    parse_gti_enrichment_output__ioc_value = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_value")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__threat_score = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:threat_score")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__verdict = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:verdict")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__confidence = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:confidence")) != "" else "null")  # pylint: disable=used-before-assignment

    create_ioc_note__artifact_note = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    
    create_ioc_note__artifact_note = (
        f"IOC : {parse_gti_enrichment_output__ioc_value}\n"
        f"Threat_score : {parse_gti_enrichment_output__threat_score}\n"
        f"Verdict : {parse_gti_enrichment_output__verdict}\n"
        f"Confidence : {parse_gti_enrichment_output__confidence}"
    )
    phantom.debug(f"artifact note : {create_ioc_note__artifact_note}")
    
    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="create_ioc_note__inputs:0:parse_gti_enrichment_output:custom_function:ioc_value", value=json.dumps(parse_gti_enrichment_output__ioc_value))
    phantom.save_block_result(key="create_ioc_note__inputs:1:parse_gti_enrichment_output:custom_function:threat_score", value=json.dumps(parse_gti_enrichment_output__threat_score))
    phantom.save_block_result(key="create_ioc_note__inputs:2:parse_gti_enrichment_output:custom_function:verdict", value=json.dumps(parse_gti_enrichment_output__verdict))
    phantom.save_block_result(key="create_ioc_note__inputs:3:parse_gti_enrichment_output:custom_function:confidence", value=json.dumps(parse_gti_enrichment_output__confidence))

    phantom.save_block_result(key="create_ioc_note:artifact_note", value=json.dumps(create_ioc_note__artifact_note))

    add_note_for_artifact(container=container)

    return


@phantom.playbook_block()
def add_malicious_ip_artifact_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("add_malicious_ip_artifact_note() called")

    ################################################################################
    # Adds the prepared malicious IP note to the artifact
    ################################################################################

    create_malicious_ip_note__artifact_note = json.loads(_ if (_ := phantom.get_run_data(key="create_malicious_ip_note:artifact_note")) != "" else "null")  # pylint: disable=used-before-assignment

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.add_note(container=container, content=create_malicious_ip_note__artifact_note, note_format="html", note_type="general", title="GTI IP Enrichment Summary")

    return


@phantom.playbook_block()
def add_note_for_artifact(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("add_note_for_artifact() called")

    ################################################################################
    # Adds the informational IOC note to the artifact.
    ################################################################################

    create_ioc_note__artifact_note = json.loads(_ if (_ := phantom.get_run_data(key="create_ioc_note:artifact_note")) != "" else "null")  # pylint: disable=used-before-assignment

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.add_note(container=container, content=create_ioc_note__artifact_note, note_format="html", note_type="general", title="GTI IOC Enrichment Summary")

    return


@phantom.playbook_block()
def block_url(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("block_url() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Blocks the malicious URL using the configured enforcement control.
    ################################################################################

    playbook_input_ioc = phantom.collect2(container=container, datapath=["playbook_input:ioc"])

    parameters = []

    # build parameters list for 'block_url' call
    for playbook_input_ioc_item in playbook_input_ioc:
        if playbook_input_ioc_item[0] is not None:
            parameters.append({
                "url": playbook_input_ioc_item[0],
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("block url", parameters=parameters, name="block_url", assets=["test-zscaler"], callback=create_malicious_url_note)

    return


@phantom.playbook_block()
def check_ioc_type(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_ioc_type() called")

    ################################################################################
    # It will determine what type of IOC as an input.
    ################################################################################

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        conditions=[
            ["parse_gti_enrichment_output:custom_function:ioc_type", "==", "ip_address"]
        ],
        conditions_dps=[
            ["parse_gti_enrichment_output:custom_function:ioc_type", "==", "ip_address"]
        ],
        name="check_ioc_type:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        block_ip(action=action, success=success, container=container, results=results, handle=handle)
        return

    # check for 'elif' condition 2
    found_match_2 = phantom.decision(
        container=container,
        conditions=[
            ["parse_gti_enrichment_output:custom_function:ioc_type", "==", "url"]
        ],
        conditions_dps=[
            ["parse_gti_enrichment_output:custom_function:ioc_type", "==", "url"]
        ],
        name="check_ioc_type:condition_2",
        delimiter=None)

    # call connected blocks if condition 2 matched
    if found_match_2:
        block_url(action=action, success=success, container=container, results=results, handle=handle)
        return

    # check for 'elif' condition 3
    found_match_3 = phantom.decision(
        container=container,
        conditions=[
            ["parse_gti_enrichment_output:custom_function:ioc_type", "==", "filehash"]
        ],
        conditions_dps=[
            ["parse_gti_enrichment_output:custom_function:ioc_type", "==", "filehash"]
        ],
        name="check_ioc_type:condition_3",
        delimiter=None)

    # call connected blocks if condition 3 matched
    if found_match_3:
        create_ticket_for_filehash(action=action, success=success, container=container, results=results, handle=handle)
        return

    # check for 'elif' condition 4
    found_match_4 = phantom.decision(
        container=container,
        conditions=[
            ["parse_gti_enrichment_output:custom_function:ioc_type", "==", "domain"]
        ],
        conditions_dps=[
            ["parse_gti_enrichment_output:custom_function:ioc_type", "==", "domain"]
        ],
        name="check_ioc_type:condition_4",
        delimiter=None)

    # call connected blocks if condition 4 matched
    if found_match_4:
        block_domain(action=action, success=success, container=container, results=results, handle=handle)
        return

    return


@phantom.playbook_block()
def create_ticket_for_filehash(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_ticket_for_filehash() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Create Service Now Ticket for malicious file hash
    ################################################################################

    parameters = []

    parameters.append({
        "table": "incident",
    })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("create ticket", parameters=parameters, name="create_ticket_for_filehash", assets=["test_servicenow"], callback=create_malicious_filehash_note)

    return


@phantom.playbook_block()
def create_malicious_url_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_malicious_url_note() called")

    ################################################################################
    # Prepares a detailed artifact note summarizing malicious URL intelligence.
    ################################################################################

    block_url_result_data = phantom.collect2(container=container, datapath=["block_url:action_result.status"], action_results=results)
    parse_gti_enrichment_output__ioc_value = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_value")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__threat_score = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:threat_score")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__verdict = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:verdict")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:severity")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__ioc_type = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_type")) != "" else "null")  # pylint: disable=used-before-assignment

    block_url_result_item_0 = [item[0] for item in block_url_result_data]

    create_malicious_url_note__artifact_note = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    
    block_note = f"As the URL is malicious, It is blocked."
    
    create_malicious_url_note__artifact_note = (
        f"URL : {parse_gti_enrichment_output__ioc_value}\n"
        f"Threat_score : {parse_gti_enrichment_output__threat_score}\n"
        f"Verdict : {parse_gti_enrichment_output__verdict}\n"
        f"{block_note}"
    )
    phantom.debug(f"artifact note : {create_malicious_url_note__artifact_note}")

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="create_malicious_url_note__inputs:0:parse_gti_enrichment_output:custom_function:ioc_value", value=json.dumps(parse_gti_enrichment_output__ioc_value))
    phantom.save_block_result(key="create_malicious_url_note__inputs:1:parse_gti_enrichment_output:custom_function:threat_score", value=json.dumps(parse_gti_enrichment_output__threat_score))
    phantom.save_block_result(key="create_malicious_url_note__inputs:2:parse_gti_enrichment_output:custom_function:verdict", value=json.dumps(parse_gti_enrichment_output__verdict))
    phantom.save_block_result(key="create_malicious_url_note__inputs:3:parse_gti_enrichment_output:custom_function:severity", value=json.dumps(parse_gti_enrichment_output__severity))
    phantom.save_block_result(key="create_malicious_url_note__inputs:4:parse_gti_enrichment_output:custom_function:ioc_type", value=json.dumps(parse_gti_enrichment_output__ioc_type))
    phantom.save_block_result(key="create_malicious_url_note__inputs:5:block_url:action_result.status", value=json.dumps(block_url_result_item_0))

    phantom.save_block_result(key="create_malicious_url_note:artifact_note", value=json.dumps(create_malicious_url_note__artifact_note))

    add_malicious_url_artifact_note(container=container)

    return


@phantom.playbook_block()
def add_malicious_url_artifact_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("add_malicious_url_artifact_note() called")

    ################################################################################
    # Adds the prepared malicious URL note to the artifact
    ################################################################################

    create_malicious_url_note__artifact_note = json.loads(_ if (_ := phantom.get_run_data(key="create_malicious_url_note:artifact_note")) != "" else "null")  # pylint: disable=used-before-assignment

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.add_note(container=container, content=create_malicious_url_note__artifact_note, note_format="html", note_type="general", title="GTI URL Enrichment Summary")

    return


@phantom.playbook_block()
def create_malicious_filehash_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_malicious_filehash_note() called")

    ################################################################################
    # Prepares a detailed artifact note summarizing malicious IOC intelligence.
    ################################################################################

    create_ticket_for_filehash_result_data = phantom.collect2(container=container, datapath=["create_ticket_for_filehash:action_result.status"], action_results=results)
    parse_gti_enrichment_output__ioc_value = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_value")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__threat_score = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:threat_score")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__verdict = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:verdict")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:severity")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__ioc_type = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_type")) != "" else "null")  # pylint: disable=used-before-assignment

    create_ticket_for_filehash_result_item_0 = [item[0] for item in create_ticket_for_filehash_result_data]

    create_malicious_filehash_note__artifact_note = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    block_note = f"As the Filehash is malicious, SNOW ticket is created."
    
    create_malicious_filehash_note__artifact_note = (
        f"FileHash : {parse_gti_enrichment_output__ioc_value}\n"
        f"Threat_score : {parse_gti_enrichment_output__threat_score}\n"
        f"Verdict : {parse_gti_enrichment_output__verdict}\n"
        f"{block_note}"
    )    
    phantom.debug(f"artifact note : {create_malicious_filehash_note__artifact_note}")

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="create_malicious_filehash_note__inputs:0:parse_gti_enrichment_output:custom_function:ioc_value", value=json.dumps(parse_gti_enrichment_output__ioc_value))
    phantom.save_block_result(key="create_malicious_filehash_note__inputs:1:parse_gti_enrichment_output:custom_function:threat_score", value=json.dumps(parse_gti_enrichment_output__threat_score))
    phantom.save_block_result(key="create_malicious_filehash_note__inputs:2:parse_gti_enrichment_output:custom_function:verdict", value=json.dumps(parse_gti_enrichment_output__verdict))
    phantom.save_block_result(key="create_malicious_filehash_note__inputs:3:parse_gti_enrichment_output:custom_function:severity", value=json.dumps(parse_gti_enrichment_output__severity))
    phantom.save_block_result(key="create_malicious_filehash_note__inputs:4:parse_gti_enrichment_output:custom_function:ioc_type", value=json.dumps(parse_gti_enrichment_output__ioc_type))
    phantom.save_block_result(key="create_malicious_filehash_note__inputs:5:create_ticket_for_filehash:action_result.status", value=json.dumps(create_ticket_for_filehash_result_item_0))

    phantom.save_block_result(key="create_malicious_filehash_note:artifact_note", value=json.dumps(create_malicious_filehash_note__artifact_note))

    add_malicious_filehash_artifact_note(container=container)

    return


@phantom.playbook_block()
def add_malicious_filehash_artifact_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("add_malicious_filehash_artifact_note() called")

    ################################################################################
    # Adds the prepared malicious File hash note to the artifact
    ################################################################################

    create_malicious_filehash_note__artifact_note = json.loads(_ if (_ := phantom.get_run_data(key="create_malicious_filehash_note:artifact_note")) != "" else "null")  # pylint: disable=used-before-assignment

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.add_note(container=container, content=create_malicious_filehash_note__artifact_note, note_format="html", note_type="general", title="GTI FileHash Enrichment Summary")

    return


@phantom.playbook_block()
def block_domain(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("block_domain() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Blocks the malicious domain using the configured enforcement control.
    ################################################################################

    playbook_input_ioc = phantom.collect2(container=container, datapath=["playbook_input:ioc"])

    parameters = []

    # build parameters list for 'block_domain' call
    for playbook_input_ioc_item in playbook_input_ioc:
        if playbook_input_ioc_item[0] is not None:
            parameters.append({
                "url": playbook_input_ioc_item[0],
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("block url", parameters=parameters, name="block_domain", assets=["test-zscaler"], callback=create_malicious_domain_note)

    return


@phantom.playbook_block()
def create_malicious_domain_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_malicious_domain_note() called")

    ################################################################################
    # Prepares a detailed artifact note summarizing malicious Domain intelligence.
    ################################################################################

    block_domain_result_data = phantom.collect2(container=container, datapath=["block_domain:action_result.status"], action_results=results)
    parse_gti_enrichment_output__ioc_value = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_value")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__threat_score = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:threat_score")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__verdict = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:verdict")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:severity")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__ioc_type = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_type")) != "" else "null")  # pylint: disable=used-before-assignment

    block_domain_result_item_0 = [item[0] for item in block_domain_result_data]

    create_malicious_domain_note__artifact_note = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    block_note = f"As the Domain is malicious, It is blocked."
    
    create_malicious_domain_note__artifact_note = (
        f"Domain : {parse_gti_enrichment_output__ioc_value}\n"
        f"Threat_score : {parse_gti_enrichment_output__threat_score}\n"
        f"Verdict : {parse_gti_enrichment_output__verdict}\n"
        f"{block_note}"
    )    
    phantom.debug(f"artifact note : {create_malicious_domain_note__artifact_note}")
    
    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="create_malicious_domain_note__inputs:0:parse_gti_enrichment_output:custom_function:ioc_value", value=json.dumps(parse_gti_enrichment_output__ioc_value))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:1:parse_gti_enrichment_output:custom_function:threat_score", value=json.dumps(parse_gti_enrichment_output__threat_score))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:2:parse_gti_enrichment_output:custom_function:verdict", value=json.dumps(parse_gti_enrichment_output__verdict))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:3:parse_gti_enrichment_output:custom_function:severity", value=json.dumps(parse_gti_enrichment_output__severity))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:4:parse_gti_enrichment_output:custom_function:ioc_type", value=json.dumps(parse_gti_enrichment_output__ioc_type))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:5:block_domain:action_result.status", value=json.dumps(block_domain_result_item_0))

    phantom.save_block_result(key="create_malicious_domain_note:artifact_note", value=json.dumps(create_malicious_domain_note__artifact_note))

    add_malicious_domain_artifact_note(container=container)

    return


@phantom.playbook_block()
def add_malicious_domain_artifact_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("add_malicious_domain_artifact_note() called")

    ################################################################################
    # Adds the prepared malicious Domain note to the artifact
    ################################################################################

    create_malicious_domain_note__artifact_note = json.loads(_ if (_ := phantom.get_run_data(key="create_malicious_domain_note:artifact_note")) != "" else "null")  # pylint: disable=used-before-assignment

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.add_note(container=container, content=create_malicious_domain_note__artifact_note, note_format="html", note_type="general", title="GTI Domain Enrichment Summary")

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return
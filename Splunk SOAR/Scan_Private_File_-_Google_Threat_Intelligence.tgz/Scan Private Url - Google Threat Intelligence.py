"""
This playbook performs a private scan of a URL using Google Threat Intelligence, evaluates the scan result, and applies enforcement and documentation based on maliciousness.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'scan_private_url' block
    scan_private_url(container=container)

    return

@phantom.playbook_block()
def scan_private_url(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("scan_private_url() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Submits the provided URL to Google Threat Intelligence for private scanning 
    # and analysis.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.requestURL","artifact:*.id"])

    parameters = []

    # build parameters list for 'scan_private_url' call
    for container_artifact_item in container_artifact_data:
        if container_artifact_item[0] is not None:
            parameters.append({
                "url": container_artifact_item[0],
                "context": {'artifact_id': container_artifact_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("scan private url", parameters=parameters, name="scan_private_url", assets=["test-gti"], callback=parse_url_scan)

    return


@phantom.playbook_block()
def parse_url_scan(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("parse_url_scan() called")

    ################################################################################
    # Extracts verdict, threat score, confidence, and supporting details from the 
    # scan response.
    ################################################################################

    scan_private_url_result_data = phantom.collect2(container=container, datapath=["scan_private_url:action_result.data.*.data"], action_results=results)

    scan_private_url_result_item_0 = [item[0] for item in scan_private_url_result_data]

    parse_url_scan__ioc_value = None
    parse_url_scan__threat_score = None
    parse_url_scan__verdict = None
    parse_url_scan__confidence = None
    parse_url_scan__severity = None
    parse_url_scan__categories = None
    parse_url_scan__malware_families = None
    parse_url_scan__first_seen = None
    parse_url_scan__last_seen = None
    parse_url_scan__raw_attributes = None
    parse_url_scan__artifact_data = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    """
    Parse GTI IOC Report output into SOAR variables.
    Direct assignment to output variables:
        parse_gti_enrichment_output__<field>
    """
    def normalize_soar_severity(value):
        """
        Map GTI severity with Splunk SOAR default severity
        """
        if not value:
            return ""
    
        value = str(value).strip().upper()
    
        mapping = {
            "SEVERITY_HIGH": "high",
            "SEVERITY_MEDIUM": "medium",
            "SEVERITY_LOW": "low",
        }
    
        return mapping.get(value, "")
    
    def get_path(dct, path, default=None):
        """
        Get Path of the attributes
        """
        cur = dct
        for key in path:
            if not isinstance(cur, dict):
                return default
            cur = cur.get(key)
            if cur is None:
                return default
        return cur

    
    
    item = scan_private_url_result_item_0[0]["attributes"]

    parse_url_scan__ioc_value = get_path( item, ["url"], 0)
    parse_url_scan__threat_score = get_path(
        item, ["gti_assessment", "threat_score", "value"], 0
    )
    parse_url_scan__verdict = get_path(
        item, ["gti_assessment", "verdict", "value"], "VERDICT_UNKNOWN"
    )
    parse_url_scan__confidence = get_path(
        item, ["gti_assessment", "contributing_factors", "gti_confidence_score"], 0
    )
    parse_url_scan__severity = normalize_soar_severity(get_path(
        item, ["gti_assessment", "severity", "value"], ""
    ))
    parse_url_scan__categories = get_path(
        item, ["gti_assessment", "contributing_factors", "normalised_categories"], []
    )
    parse_url_scan__malware_families = get_path(
        item, ["gti_assessment", "contributing_factors", "mandiant_association_malware"], False,
    )
    parse_url_scan__first_seen = item.get("first_seen_itw_date")
    parse_url_scan__last_seen = item.get("last_seen_itw_date")

    # STRICT pass-through: identical to file content
    parse_url_scan__raw_attributes = item.get("gti_assessment", {})
    parse_url_scan__artifact_data = {
        "cef": {
            f"gti__ioc_value": parse_url_scan__ioc_value,
            f"gti__threat_score": parse_url_scan__threat_score,
            f"gti__verdict": parse_url_scan__verdict,
            f"gti__confidence": parse_url_scan__confidence,
            f"gti__severity": parse_url_scan__severity,
        }
    }
    

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="parse_url_scan__inputs:0:scan_private_url:action_result.data.*.data", value=json.dumps(scan_private_url_result_item_0))

    phantom.save_block_result(key="parse_url_scan:ioc_value", value=json.dumps(parse_url_scan__ioc_value))
    phantom.save_block_result(key="parse_url_scan:threat_score", value=json.dumps(parse_url_scan__threat_score))
    phantom.save_block_result(key="parse_url_scan:verdict", value=json.dumps(parse_url_scan__verdict))
    phantom.save_block_result(key="parse_url_scan:confidence", value=json.dumps(parse_url_scan__confidence))
    phantom.save_block_result(key="parse_url_scan:severity", value=json.dumps(parse_url_scan__severity))
    phantom.save_block_result(key="parse_url_scan:categories", value=json.dumps(parse_url_scan__categories))
    phantom.save_block_result(key="parse_url_scan:malware_families", value=json.dumps(parse_url_scan__malware_families))
    phantom.save_block_result(key="parse_url_scan:first_seen", value=json.dumps(parse_url_scan__first_seen))
    phantom.save_block_result(key="parse_url_scan:last_seen", value=json.dumps(parse_url_scan__last_seen))
    phantom.save_block_result(key="parse_url_scan:raw_attributes", value=json.dumps(parse_url_scan__raw_attributes))
    phantom.save_block_result(key="parse_url_scan:artifact_data", value=json.dumps(parse_url_scan__artifact_data))

    update_artifact(container=container)

    return


@phantom.playbook_block()
def update_artifact(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("update_artifact() called")

    ################################################################################
    # Updates the artifact with severity and scan-related context based on the analysis 
    # result.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.id","artifact:*.id"])
    parse_url_scan__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_url_scan:severity")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_url_scan__artifact_data = json.loads(_ if (_ := phantom.get_run_data(key="parse_url_scan:artifact_data")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    # build parameters list for 'update_artifact' call
    for container_artifact_item in container_artifact_data:
        parameters.append({
            "name": None,
            "tags": None,
            "label": None,
            "severity": parse_url_scan__severity,
            "cef_field": None,
            "cef_value": None,
            "input_json": parse_url_scan__artifact_data,
            "artifact_id": container_artifact_item[0],
            "cef_data_type": None,
            "overwrite_tags": None,
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.custom_function(custom_function="community/artifact_update", parameters=parameters, name="update_artifact", callback=check_malicious_url)

    return


@phantom.playbook_block()
def check_malicious_url(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_malicious_url() called")

    ################################################################################
    # Determines whether the scanned URL is malicious based on scan verdict and score.
    ################################################################################

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        logical_operator="or",
        conditions=[
            ["parse_url_scan:custom_function:threat_score", ">=", 90],
            ["parse_url_scan:custom_function:severity", "==", "high"],
            ["parse_url_scan:custom_function:verdict", "==", "VERDICT_MALICIOUS"]
        ],
        conditions_dps=[
            ["parse_url_scan:custom_function:threat_score", ">=", 90],
            ["parse_url_scan:custom_function:severity", "==", "high"],
            ["parse_url_scan:custom_function:verdict", "==", "VERDICT_MALICIOUS"]
        ],
        name="check_malicious_url:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        confirm_url_blocking(action=action, success=success, container=container, results=results, handle=handle)
        return

    return


@phantom.playbook_block()
def block_url(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("block_url() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Blocks the malicious URL using the configured web or network control.
    ################################################################################

    parse_url_scan__ioc_value = json.loads(_ if (_ := phantom.get_run_data(key="parse_url_scan:ioc_value")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    if parse_url_scan__ioc_value is not None:
        parameters.append({
            "url": parse_url_scan__ioc_value,
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("block url", parameters=parameters, name="block_url", assets=["zscaler"], callback=create_malicious_url_note)

    return


@phantom.playbook_block()
def create_malicious_url_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_malicious_url_note() called")

    ################################################################################
    # Prepares an artifact note summarizing malicious scan findings and enforcement 
    # action.
    ################################################################################

    block_url_result_data = phantom.collect2(container=container, datapath=["block_url:action_result.status"], action_results=results)
    parse_url_scan__ioc_value = json.loads(_ if (_ := phantom.get_run_data(key="parse_url_scan:ioc_value")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_url_scan__raw_attributes = json.loads(_ if (_ := phantom.get_run_data(key="parse_url_scan:raw_attributes")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_url_scan__threat_score = json.loads(_ if (_ := phantom.get_run_data(key="parse_url_scan:threat_score")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_url_scan__verdict = json.loads(_ if (_ := phantom.get_run_data(key="parse_url_scan:verdict")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_url_scan__confidence = json.loads(_ if (_ := phantom.get_run_data(key="parse_url_scan:confidence")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_url_scan__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_url_scan:severity")) != "" else "null")  # pylint: disable=used-before-assignment

    block_url_result_item_0 = [item[0] for item in block_url_result_data]

    create_malicious_url_note__artifact_note = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
        
    block_note = ''
    phantom.debug(f"block_url_result_item_0 : {block_url_result_item_0}")
    if block_url_result_item_0[0] == "success":
        block_note = f"As the URL is malicious it is blocked."
    phantom.debug(f"block_note : {block_note}")
    create_malicious_url_note__artifact_note = (
        f"URL : {parse_url_scan__ioc_value}\n"
        f"Threat_score : {parse_url_scan__threat_score}\n"
        f"verdict : {parse_url_scan__verdict}\n"
        f"Confidence : {parse_url_scan__confidence}\n"
        f"{block_note}"
    )
    phantom.debug(f"malicious artifact_note : {create_malicious_url_note__artifact_note}")


    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="create_malicious_url_note__inputs:0:parse_url_scan:custom_function:ioc_value", value=json.dumps(parse_url_scan__ioc_value))
    phantom.save_block_result(key="create_malicious_url_note__inputs:1:parse_url_scan:custom_function:raw_attributes", value=json.dumps(parse_url_scan__raw_attributes))
    phantom.save_block_result(key="create_malicious_url_note__inputs:2:parse_url_scan:custom_function:threat_score", value=json.dumps(parse_url_scan__threat_score))
    phantom.save_block_result(key="create_malicious_url_note__inputs:3:parse_url_scan:custom_function:verdict", value=json.dumps(parse_url_scan__verdict))
    phantom.save_block_result(key="create_malicious_url_note__inputs:4:parse_url_scan:custom_function:confidence", value=json.dumps(parse_url_scan__confidence))
    phantom.save_block_result(key="create_malicious_url_note__inputs:5:parse_url_scan:custom_function:severity", value=json.dumps(parse_url_scan__severity))
    phantom.save_block_result(key="create_malicious_url_note__inputs:6:block_url:action_result.status", value=json.dumps(block_url_result_item_0))

    phantom.save_block_result(key="create_malicious_url_note:artifact_note", value=json.dumps(create_malicious_url_note__artifact_note))

    add_artifact_note(container=container)

    return


@phantom.playbook_block()
def add_artifact_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("add_artifact_note() called")

    ################################################################################
    # Adds the malicious URL scan note to the artifact.
    ################################################################################

    create_malicious_url_note__artifact_note = json.loads(_ if (_ := phantom.get_run_data(key="create_malicious_url_note:artifact_note")) != "" else "null")  # pylint: disable=used-before-assignment

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.add_note(container=container, content=create_malicious_url_note__artifact_note, note_format="html", note_type="general", title="GTI URL Private Scanning Summary")

    return


@phantom.playbook_block()
def confirm_url_blocking(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("confirm_url_blocking() called")

    ################################################################################
    # Requests user confirmation before blocking a URL identified as malicious.
    ################################################################################

    # set approver and message variables for phantom.prompt call

    user = phantom.collect2(container=container, datapath=["playbook:launching_user.name"])[0][0]
    role = None
    message = """The URL {0} has been identified as malicious based on Google Threat Intelligence private scan results.\n"""

    # parameter list for template variable replacement
    parameters = [
        "parse_url_scan:custom_function:ioc_value"
    ]

    # responses
    response_types = [
        {
            "prompt": "Do you want to proceed with blocking this URL?",
            "options": {
                "type": "list",
                "required": True,
                "choices": [
                    "Yes",
                    "No"
                ],
            },
        }
    ]

    phantom.prompt2(container=container, user=user, role=role, message=message, respond_in_mins=30, name="confirm_url_blocking", parameters=parameters, response_types=response_types, callback=check_user_approval)

    return


@phantom.playbook_block()
def check_user_approval(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_user_approval() called")

    ################################################################################
    # Evaluates whether the user approved blocking the malicious URL.
    ################################################################################

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        conditions=[
            ["confirm_url_blocking:action_result.summary.responses.0", "==", "Yes"]
        ],
        conditions_dps=[
            ["confirm_url_blocking:action_result.summary.responses.0", "==", "Yes"]
        ],
        name="check_user_approval:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        block_url(action=action, success=success, container=container, results=results, handle=handle)
        return

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return
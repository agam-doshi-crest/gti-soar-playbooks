"""
This playbook performs a private scan of a URL using Google Threat Intelligence, evaluates the scan result, and applies enforcement and documentation based on maliciousness.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'scan_private_file' block
    scan_private_file(container=container)

    return

@phantom.playbook_block()
def scan_private_file(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("scan_private_file() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Submits the file to Google Threat Intelligence for private sandbox analysis.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.vaultId","artifact:*.id"])

    parameters = []

    # build parameters list for 'scan_private_file' call
    for container_artifact_item in container_artifact_data:
        if container_artifact_item[0] is not None:
            parameters.append({
                "file_hash": container_artifact_item[0],
                "context": {'artifact_id': container_artifact_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("scan private file", parameters=parameters, name="scan_private_file", assets=["test-gti"], callback=parse_file_scan)

    return


@phantom.playbook_block()
def parse_file_scan(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("parse_file_scan() called")

    ################################################################################
    # Extracts verdict, threat score, confidence, and malware details from the scan 
    # response.
    ################################################################################

    scan_private_file_result_data = phantom.collect2(container=container, datapath=["scan_private_file:action_result.data.*.data"], action_results=results)

    scan_private_file_result_item_0 = [item[0] for item in scan_private_file_result_data]

    parse_file_scan__file_id = None
    parse_file_scan__threat_score = None
    parse_file_scan__verdict = None
    parse_file_scan__confidence = None
    parse_file_scan__severity = None
    parse_file_scan__categories = None
    parse_file_scan__malware_families = None
    parse_file_scan__first_seen = None
    parse_file_scan__last_seen = None
    parse_file_scan__raw_attributes = None
    parse_file_scan__artifact_data = None
    parse_file_scan__ticket_description = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    """
    Parse GTI IOC Report output into SOAR variables.
    Direct assignment to output variables:
        parse_gti_enrichment_output__<field>
    """
    def normalize_soar_severity(value):
        """
        Map severity as per splunk soar's default severities
        """
        if not value:
            return ""
    
        value = str(value).strip().upper()
    
        mapping = {
            "SEVERITY_HIGH": "high",
            "SEVERITY_MEDIUM": "medium",
            "SEVERITY_LOW": "low",
        }
    
        return mapping.get(value, "")
    
    def get_path(dct, path, default=None):
        """
        Get path of the attributes
        """
        cur = dct
        for key in path:
            if not isinstance(cur, dict):
                return default
            cur = cur.get(key)
            if cur is None:
                return default
        return cur

    item = scan_private_file_result_item_0[0]["attributes"]

    parse_file_scan__file_id = get_path( item, ["sha1"], 0)
    parse_file_scan__threat_score = get_path(
        item, ["gti_assessment", "threat_score", "value"], 0
    )
    parse_file_scan__verdict = get_path(
        item, ["gti_assessment", "verdict", "value"], "VERDICT_UNKNOWN"
    )
    desc = parse_file_scan__verdict = get_path(
        item, ["gti_assessment", "description"], ""
    )
    parse_file_scan__confidence = get_path(
        item, ["gti_assessment", "contributing_factors", "gti_confidence_score"], 0
    )
    parse_file_scan__severity = normalize_soar_severity(get_path(
        item, ["gti_assessment", "severity", "value"], ""
    ))
    parse_file_scan__categories = get_path(
        item, ["gti_assessment", "contributing_factors", "normalised_categories"], []
    )
    parse_file_scan__malware_families = get_path(
        item, ["gti_assessment", "contributing_factors", "mandiant_association_malware"], False,
    )
    parse_file_scan__first_seen = item.get("first_seen_itw_date")
    parse_file_scan__last_seen = item.get("last_seen_itw_date")

    # STRICT pass-through: identical to file content
    parse_file_scan__raw_attributes = item.get("gti_assessment", {})
    parse_file_scan__artifact_data = {
        "cef": {
            f"gti__file_id": parse_file_scan__file_id,
            f"gti__threat_score": parse_file_scan__threat_score,
            f"gti__verdict": parse_file_scan__verdict,
            f"gti__confidence": parse_file_scan__confidence,
            f"gti__severity": parse_file_scan__severity,
        }
    }
    parse_file_scan__ticket_description = f"For File ID : {parse_file_scan__file_id}\n GTI Description : {desc}\n Threat Score: {parse_file_scan__threat_score}\n Verdict: {parse_file_scan__verdict}\n Confidence: {parse_file_scan__confidence}\n Severity: {parse_file_scan__severity}"
    

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="parse_file_scan__inputs:0:scan_private_file:action_result.data.*.data", value=json.dumps(scan_private_file_result_item_0))

    phantom.save_block_result(key="parse_file_scan:file_id", value=json.dumps(parse_file_scan__file_id))
    phantom.save_block_result(key="parse_file_scan:threat_score", value=json.dumps(parse_file_scan__threat_score))
    phantom.save_block_result(key="parse_file_scan:verdict", value=json.dumps(parse_file_scan__verdict))
    phantom.save_block_result(key="parse_file_scan:confidence", value=json.dumps(parse_file_scan__confidence))
    phantom.save_block_result(key="parse_file_scan:severity", value=json.dumps(parse_file_scan__severity))
    phantom.save_block_result(key="parse_file_scan:categories", value=json.dumps(parse_file_scan__categories))
    phantom.save_block_result(key="parse_file_scan:malware_families", value=json.dumps(parse_file_scan__malware_families))
    phantom.save_block_result(key="parse_file_scan:first_seen", value=json.dumps(parse_file_scan__first_seen))
    phantom.save_block_result(key="parse_file_scan:last_seen", value=json.dumps(parse_file_scan__last_seen))
    phantom.save_block_result(key="parse_file_scan:raw_attributes", value=json.dumps(parse_file_scan__raw_attributes))
    phantom.save_block_result(key="parse_file_scan:artifact_data", value=json.dumps(parse_file_scan__artifact_data))
    phantom.save_block_result(key="parse_file_scan:ticket_description", value=json.dumps(parse_file_scan__ticket_description))

    update_artifact(container=container)

    return


@phantom.playbook_block()
def update_artifact(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("update_artifact() called")

    ################################################################################
    # Normalizes scan results for decision-making and reporting.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.id","artifact:*.id"])
    parse_file_scan__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_file_scan:severity")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_file_scan__artifact_data = json.loads(_ if (_ := phantom.get_run_data(key="parse_file_scan:artifact_data")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    # build parameters list for 'update_artifact' call
    for container_artifact_item in container_artifact_data:
        parameters.append({
            "name": None,
            "tags": None,
            "label": None,
            "severity": parse_file_scan__severity,
            "cef_field": None,
            "cef_value": None,
            "input_json": parse_file_scan__artifact_data,
            "artifact_id": container_artifact_item[0],
            "cef_data_type": None,
            "overwrite_tags": None,
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.custom_function(custom_function="community/artifact_update", parameters=parameters, name="update_artifact", callback=check_malicious_file)

    return


@phantom.playbook_block()
def check_malicious_file(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_malicious_file() called")

    ################################################################################
    # Determines whether the scanned file is malicious based on scan verdict and score.
    ################################################################################

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        logical_operator="or",
        conditions=[
            ["parse_file_scan:custom_function:threat_score", ">=", 90],
            ["parse_file_scan:custom_function:severity", "==", "high"],
            ["parse_file_scan:custom_function:verdict", "==", "VERDICT_MALICIOUS"]
        ],
        conditions_dps=[
            ["parse_file_scan:custom_function:threat_score", ">=", 90],
            ["parse_file_scan:custom_function:severity", "==", "high"],
            ["parse_file_scan:custom_function:verdict", "==", "VERDICT_MALICIOUS"]
        ],
        name="check_malicious_file:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        create_snow_ticket(action=action, success=success, container=container, results=results, handle=handle)
        return

    return


@phantom.playbook_block()
def create_snow_ticket(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_snow_ticket() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Creates a ServiceNow incident for a malicious file detected via private scan.
    ################################################################################

    parse_file_scan__ticket_description = json.loads(_ if (_ := phantom.get_run_data(key="parse_file_scan:ticket_description")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    parameters.append({
        "table": "incident",
        "description": parse_file_scan__ticket_description,
        "short_description": "Malicious File Detected via Google Threat Intelligence Private Scan",
    })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("create ticket", parameters=parameters, name="create_snow_ticket", assets=["test_snow"], callback=create_malicious_file_note)

    return


@phantom.playbook_block()
def create_malicious_file_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_malicious_file_note() called")

    ################################################################################
    # Prepares an artifact note summarizing malicious file scan findings.
    ################################################################################

    create_snow_ticket_result_data = phantom.collect2(container=container, datapath=["create_snow_ticket:action_result.status","create_snow_ticket:action_result.data.*.number"], action_results=results)
    parse_file_scan__file_id = json.loads(_ if (_ := phantom.get_run_data(key="parse_file_scan:file_id")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_file_scan__threat_score = json.loads(_ if (_ := phantom.get_run_data(key="parse_file_scan:threat_score")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_file_scan__verdict = json.loads(_ if (_ := phantom.get_run_data(key="parse_file_scan:verdict")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_file_scan__confidence = json.loads(_ if (_ := phantom.get_run_data(key="parse_file_scan:confidence")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_file_scan__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_file_scan:severity")) != "" else "null")  # pylint: disable=used-before-assignment

    create_snow_ticket_result_item_0 = [item[0] for item in create_snow_ticket_result_data]
    create_snow_ticket_result_item_1 = [item[1] for item in create_snow_ticket_result_data]

    create_malicious_file_note__artifact_note = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    create_malicious_file_note__artifact_note =(
        f"File : {parse_file_scan__file_id}\n"
        f"Threat_score : {parse_file_scan__threat_score}\n"
        f"verdict : {parse_file_scan__verdict}\n"
        f"Confidence : {parse_file_scan__confidence}\n"
        f"As the Filehash is malicious, SNOW ticket is created.\n"
        f"SNOW Ticket ID : {create_snow_ticket_result_item_1[0]}"
    )
    phantom.debug(f"malicious artifact_note : {create_malicious_file_note__artifact_note}")


    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="create_malicious_file_note__inputs:0:parse_file_scan:custom_function:file_id", value=json.dumps(parse_file_scan__file_id))
    phantom.save_block_result(key="create_malicious_file_note__inputs:1:parse_file_scan:custom_function:threat_score", value=json.dumps(parse_file_scan__threat_score))
    phantom.save_block_result(key="create_malicious_file_note__inputs:2:parse_file_scan:custom_function:verdict", value=json.dumps(parse_file_scan__verdict))
    phantom.save_block_result(key="create_malicious_file_note__inputs:3:parse_file_scan:custom_function:confidence", value=json.dumps(parse_file_scan__confidence))
    phantom.save_block_result(key="create_malicious_file_note__inputs:4:parse_file_scan:custom_function:severity", value=json.dumps(parse_file_scan__severity))
    phantom.save_block_result(key="create_malicious_file_note__inputs:5:create_snow_ticket:action_result.status", value=json.dumps(create_snow_ticket_result_item_0))
    phantom.save_block_result(key="create_malicious_file_note__inputs:6:create_snow_ticket:action_result.data.*.number", value=json.dumps(create_snow_ticket_result_item_1))

    phantom.save_block_result(key="create_malicious_file_note:artifact_note", value=json.dumps(create_malicious_file_note__artifact_note))

    add_artifact_note(container=container)

    return


@phantom.playbook_block()
def add_artifact_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("add_artifact_note() called")

    ################################################################################
    # Adds the malicious file scan note to the artifact.
    ################################################################################

    create_malicious_file_note__artifact_note = json.loads(_ if (_ := phantom.get_run_data(key="create_malicious_file_note:artifact_note")) != "" else "null")  # pylint: disable=used-before-assignment

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.add_note(container=container, content=create_malicious_file_note__artifact_note, note_format="html", note_type="general", title="GTI File Private Scanning Summary")

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return